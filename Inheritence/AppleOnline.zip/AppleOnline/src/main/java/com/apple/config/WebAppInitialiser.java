package com.apple.config;



import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import com.apple.config.RootConfig;
import com.apple.config.WebConfig;

public class WebAppInitialiser extends AbstractAnnotationConfigDispatcherServletInitializer {


@Override
protected String[] getServletMappings() {
	System.out.println("hi in SpittrWebAppInitializer 1");
return new String[] { "/" };
}
@Override
protected Class<?>[] getRootConfigClasses() {
	System.out.println("hi in SpittrWebAppInitializer "+RootConfig.class);
return new Class<?>[] { RootConfig.class };
}
@Override
protected Class<?>[] getServletConfigClasses() {
	System.out.println("hi in SpittrWebAppInitializer 3");
return new Class<?>[] { WebConfig.class };
}
}
