package com.apple.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.apple.dao.StudentDAO;
import com.apple.model.Student;

public class StudentServiceImpl implements StudentDAO {
	@Autowired
	StudentDAO studentDao;
	
	@Transactional
	public void add(Student student) {
		studentDao.add(student);

	}
	
	@Transactional
	public void edit(Student student) {
		studentDao.edit(student);

	}
	
	@Transactional
	public void delete(int studentId) {
		studentDao.delete(studentId);
	}
	
	@Transactional
	public Student getStudent(int studentId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Transactional
	public List getAllStudent() {
		return studentDao.getAllStudent();
		
	}

}
