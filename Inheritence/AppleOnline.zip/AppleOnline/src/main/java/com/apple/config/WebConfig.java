package com.apple.config;



import java.util.Properties;

import javax.sql.DataSource;


import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.
DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.
WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.
InternalResourceViewResolver;

import com.apple.dao.StudentDAO;
import com.apple.dao.StudentDAOImpl;
import com.apple.model.Student;
@Configuration
@EnableWebMvc
@EnableTransactionManagement
@ComponentScan("com.apple")
public class WebConfig
extends WebMvcConfigurerAdapter {
	private static void soout() {
		System.out.println("hi in root config");

	}
	@Bean(name = "dataSource")
	public DataSource getDataSource() {
	    BasicDataSource dataSource = new BasicDataSource();
	    dataSource.setDriverClassName("org.apache.derby.jdbc.ClientDriver");
	    dataSource.setUrl("jdbc:derby://localhost:1527/student;create=true");
	    dataSource.setUsername("user");
	    dataSource.setPassword("123");
	 
	    return dataSource;
	}
@Bean
public ViewResolver viewResolver() {
InternalResourceViewResolver resolver =
new InternalResourceViewResolver();
resolver.setPrefix("/WEB-INF/jsp/");
resolver.setSuffix(".jsp");
resolver.setExposeContextBeansAsAttributes(true);
System.out.println("spitter hi");
return resolver;
}
private Properties getHibernateProperties() {
	Properties properties = new Properties();
	properties.put("hibernate.show_sql", "true");
	properties.put("hibernate.dialect", "org.hibernate.dialect.DerbyDialect");
	return properties;
}

@Autowired
@Bean(name = "sessionFactory")
public SessionFactory getSessionFactory(DataSource dataSource) {
 
    LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
 
    sessionBuilder.addAnnotatedClasses(Student.class);
 
    return sessionBuilder.buildSessionFactory();
}
@Autowired
@Bean(name = "transactionManager")
public HibernateTransactionManager getTransactionManager(
        SessionFactory sessionFactory) {
    HibernateTransactionManager transactionManager = new HibernateTransactionManager(
            sessionFactory);
 
    return transactionManager;
}

@Autowired
@Bean(name ="studentDAO")
public StudentDAO getStudentDao(SessionFactory sessionFactory) {
	return new StudentDAOImpl(sessionFactory);
}
@Override
public void configureDefaultServletHandling(
DefaultServletHandlerConfigurer configurer) {
configurer.enable();
System.out.println("hi config");
}
}

