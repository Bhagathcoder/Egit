package com.bhagath;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
	Shape shape=(Shape) context.getBean("circle");
	shape.draw();
	

	}

}
