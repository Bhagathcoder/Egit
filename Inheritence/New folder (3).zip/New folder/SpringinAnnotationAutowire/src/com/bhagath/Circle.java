package com.bhagath;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Circle implements Shape {
	private Point pointA;

	public Point getPointA() {
		return pointA;
	}
	@Autowired
	@Qualifier("circleRelated")
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}

	
	public void draw() {
		
		System.out.println("PointA"+pointA.getX()+","+pointA.getY() );
	}
	

}
