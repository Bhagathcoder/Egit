package com.bhagath.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.bhagath.buisiness.Circle;

@Component
public class JdbcCDaoImpl {
	
	private DataSource dataSource;
	private JdbcTemplate template=new JdbcTemplate();
	
	

	public DataSource getDataSource() {
		return dataSource;
	}


	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.template =new JdbcTemplate(dataSource) ;
	}
	
	public int getCircleCount(){
		String query="select Count(*) from circle";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		return template.queryForObject(query, Integer.class);
		
	}
	
	public Circle getCircle(int id){
		String query="select * from circle where id=?";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		return template.queryForObject(query,new Object[] {id},new CircleMapper());
		
		
	}
	
	private static final class CircleMapper implements RowMapper<Circle>{

		@Override
		public Circle mapRow(ResultSet rs, int rowNum) throws SQLException {
		Circle circle = new Circle();
		circle.setId(rs.getInt("ID"));
		circle.setName(rs.getString("NAME"));
			return circle;
		}
		
	}
	
	public List<Circle> getAllCircle(){
		String query="select * from circle";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		return template.query(query,new CircleMapper());
		
	}
	public void insertIntoCircle(Circle circle){
		String sql="INSERT INTO CIRCLE (ID,NAME) VALUES(?,?)";
		template.update(sql,new Object[]{circle.getId(),circle.getName()} );
		
	}
	
	public void createTriangleTable(){
		String sql="CREATE TABLE TRIANGLE (ID INTEGER,NAME VARCHAR2(50))";
		template.execute(sql);
		
	}
	



	public JdbcTemplate getTemplate() {
		return template;
	}



	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}



	
	
	
	

}
