package com.bhagath.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bhagath.buisiness.Circle;
import com.bhagath.dao.JdbcCDaoImpl;

public class JDBCDemo {

	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		JdbcCDaoImpl dao=ctx.getBean("jdbcCDaoImpl",JdbcCDaoImpl.class);
		System.out.println(dao.getCircle(1).getName());
		
		for(Circle c:dao.getAllCircle()){
			System.out.println("circle name is "+c.getName());
		}
		/*Circle c=new Circle(4, "FOURTH CIRCLE");
		dao.insertIntoCircle(c);*/
		

	}

}
