package com.bhagath.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.bhagath.buisiness.Circle;


public class DaoSimple extends NamedParameterJdbcDaoSupport {
	public int getCircleCount(){
		String query="select Count(*) from circle";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		return this.getJdbcTemplate().queryForObject(query, Integer.class);  
		
	}
	
	public Circle getCircle(int id){
		String query="select * from circle where id=?";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		return this.getJdbcTemplate().queryForObject(query,new Object[] {id},new CircleMapper());
		
		
	}
	
	private static final class CircleMapper implements RowMapper<Circle>{

		@Override
		public Circle mapRow(ResultSet rs, int rowNum) throws SQLException {
		Circle circle = new Circle();
		circle.setId(rs.getInt("ID"));
		circle.setName(rs.getString("NAME"));
			return circle;
		}
		
	}
	
	public List<Circle> getAllCircle(){
		String query="select * from circle where id  between(:a) and (:b)";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		  Map m1 = new HashMap(); 
	      m1.put("a", "1");
	      m1.put("b", "4");
	     
		SqlParameterSource namedParameter=new MapSqlParameterSource(m1);
		return this.getNamedParameterJdbcTemplate().query(query, namedParameter,new CircleMapper());
		
	}
	
	

}
