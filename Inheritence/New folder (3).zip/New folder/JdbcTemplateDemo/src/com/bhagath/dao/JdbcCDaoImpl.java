package com.bhagath.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bhagath.buisiness.Circle;

@Component
public class JdbcCDaoImpl {
	@Autowired
	private DataSource dataSource;  
	
	

	public DataSource getDataSource() {
		return dataSource;
	}



	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}



	public Circle getCircle(int id){
		Connection conn=null;
		Circle circle=null;
		
		try {
			
			conn=dataSource.getConnection();
			
			PreparedStatement ps=conn.prepareStatement("Select * from circle where id=?");
			ps.setInt(1, id);
			
			
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				circle=new Circle(rs.getInt(1),rs.getString(2));
				
			}
			
			ps.close();
			rs.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return circle;
		
		
		
	}
	
	

}
