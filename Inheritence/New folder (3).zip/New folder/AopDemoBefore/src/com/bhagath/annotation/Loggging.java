package com.bhagath.annotation;

public @interface Loggging {

}
