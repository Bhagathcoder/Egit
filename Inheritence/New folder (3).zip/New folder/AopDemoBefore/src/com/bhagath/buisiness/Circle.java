package com.bhagath.buisiness;

import com.bhagath.annotation.Loggging;

public class Circle {
	private String name;

	public String getName() {
		return name;
	}
	
	@Loggging
	public String setName(String name)  {
		this.name = name;
		System.out.println("Setter method");
		return name;
	
		
	}
	

}
