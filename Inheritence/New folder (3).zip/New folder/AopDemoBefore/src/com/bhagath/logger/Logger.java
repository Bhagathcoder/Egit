package com.bhagath.logger;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class Logger {
	
	@Around("@annotation(com.bhagath.annotation.Loggging))")
	public Object myAroundAdvice(ProceedingJoinPoint proceedingJooinPoint){
		Object returnVale=null;
		
		try {
			System.out.println("Before advice");
			returnVale=proceedingJooinPoint.proceed();
			System.out.println("After Advice");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return returnVale;
	}

}
