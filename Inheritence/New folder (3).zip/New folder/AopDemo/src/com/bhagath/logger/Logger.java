package com.bhagath.logger;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Logger {
	@Before("execution(public String getName())")
	public void logMessage(){
		
		System.out.println("logging message");
	}

}
