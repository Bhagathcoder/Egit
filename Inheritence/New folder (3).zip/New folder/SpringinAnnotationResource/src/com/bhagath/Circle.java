package com.bhagath;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;


@Component  /*creates bean no need to write bean class in xml file */

public class Circle implements Shape {
	private Point circle;
	@Autowired
	private MessageSource message;

	public MessageSource getMessage() {
		return message;
	}
	public void setMessage(MessageSource message) {
		this.message = message;
	}
	public Point getCircle() {
		return circle;
	}
	@Resource (name="pointC")
	//@Qualifier("circleRelated")
	public void setCircle(Point circle) {
		this.circle = circle;
	}

	
	public void draw() {
		System.out.println(message.getMessage("circle.draw",null, null));
		
		System.out.println(message.getMessage("circle.point",new Object[] {circle.getX(),circle.getY()}, null) );
	}
	@PostConstruct
	public void myInit()  {
		System.out.println("bean Initializing method");
		
	}
	
    @PreDestroy
	public void cleanUp() {
		// TODO Auto-generated method stub
		System.out.println(" bean destroymethod");
		
		
	}

}
