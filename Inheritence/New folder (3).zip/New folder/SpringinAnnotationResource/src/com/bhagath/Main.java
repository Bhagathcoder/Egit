package com.bhagath;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
	Shape shape=(Shape) context.getBean("circle");
	context.registerShutdownHook();
	shape.draw();
	System.out.println(context.getMessage("greeting",null, null));

	}

}
