package com.bhagath.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bhagath.buisiness.Circle;

public class JdbcCDaoImpl {
	public Circle getCircle(int id){
		Connection conn=null;
		Circle circle=null;
		String driver="org.apache.derby.jdbc.ClientDriver";
		try {
			Class.forName(driver).newInstance();
			conn=DriverManager.getConnection("jdbc:derby://localhost:1527/db");
			PreparedStatement ps=conn.prepareStatement("Select * from circle where id=?");
			ps.setInt(1, id);
			
			
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				circle=new Circle(rs.getInt(1),rs.getString(2));
				
			}
			
			ps.close();
			rs.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return circle;
		
		
		
	}
	
	

}
