package com.bhagath.main;

import com.bhagath.buisiness.Circle;
import com.bhagath.dao.JdbcCDaoImpl;

public class JDBCDemo {

	public static void main(String[] args) {
		JdbcCDaoImpl dao=new JdbcCDaoImpl();
		System.out.println(dao.getCircle(1).getName());

	}

}
