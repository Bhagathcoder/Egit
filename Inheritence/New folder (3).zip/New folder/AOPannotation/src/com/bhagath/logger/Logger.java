package com.bhagath.logger;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class Logger {
	
	/*@Before("execution(public String getName())")
	public void logMessage(){
		
		System.out.println("logging message");
	}*/
	
	@Pointcut("within(com.bhagath.buisiness.Circle)")
	public void logMessageForAllCircleMethod(){
		//this is  a dummy method and pointcut can be used by using this method
	}
	/*@Before("logMessageForAllCircleMethod()")
	public void logSecondMessage(){
		
		System.out.println("logging second message");
	}
	
	@Before("args(String)")
	public void stringArgumentMethods(){
		System.out.println("A method that takes string called Before");
	}
	@After("args(String)")
	public void stringArgumentMethodsAfter(){
		System.out.println("A method that takes string called After");
	}
	
	@AfterReturning("args(String)")
	public void stringArgumentMethodsAfterReturning(){
		System.out.println("This executes only after a method executed");
	}
	
	@AfterThrowing("args(String)")
	public void stringArgumentMethodsAfterThrowingError(){
		System.out.println("This executes only after a error");
	}
	@AfterReturning("args(name)")
	public void stringArgumentMethodsAfterReturning(String name){
		System.out.println("This executes only after a method executed and argument passed"+name);
	}
	@AfterReturning(pointcut="args(name)",returning="returnString")
	public void stringArgumentMethodsAfterReturning(String name,String returnString){
		System.out.println("This executes only after a method executed and argument passed "+name + "and returning string is "+returnString);
	}
	
	@AfterThrowing(pointcut="args(s)",throwing="ex")
	public void stringArgumentMethodsAfterThrowingError(String s,RuntimeException ex){
		System.out.println("This executes only after a error  " + ex);
	}
	*/
	@Around("logMessageForAllCircleMethod()")
	public Object myAroundAdvice(ProceedingJoinPoint proceedingJooinPoint){
		Object returnVale=null;
		
		try {
			System.out.println("Before advice");
			returnVale=proceedingJooinPoint.proceed();
			System.out.println("After Advice");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return returnVale;
	}

}
