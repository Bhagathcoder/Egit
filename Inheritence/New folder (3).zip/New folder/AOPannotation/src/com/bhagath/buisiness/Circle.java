package com.bhagath.buisiness;

public class Circle {
	private String name;

	public String getName() {
		return name;
	}

	public String setName(String name)  {
		this.name = name;
		System.out.println("Setter method");
		return name;
	
		
	}
	

}
