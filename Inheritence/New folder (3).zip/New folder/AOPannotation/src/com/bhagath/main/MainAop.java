package com.bhagath.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bhagath.model.DrawShape;

public class MainAop {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		DrawShape shape=context.getBean("drawShape",DrawShape.class);
		System.out.println(shape.getCircle().getName()); 
		
		shape.getCircle().setName("Hi");

	}

}
