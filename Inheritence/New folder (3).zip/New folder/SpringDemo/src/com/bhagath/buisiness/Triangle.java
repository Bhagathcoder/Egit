package com.bhagath.buisiness;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.bhagath.bean.Point;

/**
 * @author Bhagath.Ac
 *
 */
public class Triangle implements ApplicationContextAware,BeanNameAware,DisposableBean,InitializingBean {
	private Point pointA;
	private Point pointB;
	private Point pointC;
	public Point getPointA() {
		return pointA;
	}
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}
	public Point getPointB() {
		return pointB;
	}
	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}
	public Point getPointC() {
		return pointC;
	}
	public void setPointC(Point pointC) {
		this.pointC = pointC;
	}
	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		
		
	}
	@Override
	public void setBeanName(String arg0) {
	System.out.println(arg0);
		
	}
	public void run(){
		System.out.println("PointA"+pointA.getX()+","+pointA.getY() );
		System.out.println("PointB"+pointB.getX()+","+pointB.getY() );
		System.out.println("PointA"+pointC.getX()+","+pointC.getY() );
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Initializing method");
		
	}
	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("destroymethod");
		
		
	}
	public void myInit()  {
		System.out.println("bean Initializing method");
		
	}

	public void cleanUp() {
		// TODO Auto-generated method stub
		System.out.println(" bean destroymethod");
		
		
	}
	
	

}
