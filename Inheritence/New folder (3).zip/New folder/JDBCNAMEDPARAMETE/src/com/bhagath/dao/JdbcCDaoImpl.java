package com.bhagath.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.bhagath.buisiness.Circle;

@Component
public class JdbcCDaoImpl {
	
	private DataSource dataSource;
	private JdbcTemplate template=new JdbcTemplate();
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	

	public DataSource getDataSource() {
		return dataSource;
	}


	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.template =new JdbcTemplate(dataSource) ;
		this.namedParameterJdbcTemplate=new NamedParameterJdbcTemplate(dataSource);
	}
	
	public int getCircleCount(){
		String query="select Count(*) from circle";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		return template.queryForObject(query, Integer.class);
		
	}
	
	public Circle getCircle(int id){
		String query="select * from circle where id=?";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		return template.queryForObject(query,new Object[] {id},new CircleMapper());
		
		
	}
	
	private static final class CircleMapper implements RowMapper<Circle>{

		@Override
		public Circle mapRow(ResultSet rs, int rowNum) throws SQLException {
		Circle circle = new Circle();
		circle.setId(rs.getInt("ID"));
		circle.setName(rs.getString("NAME"));
			return circle;
		}
		
	}
	
	public List<Circle> getAllCircle(){
		String query="select * from circle where id  between(:a) and (:b)";
		//template.setDataSource(dataSource); this is done at setDatasource method 
		  Map m1 = new HashMap(); 
	      m1.put("a", "1");
	      m1.put("b", "4");
	     
		SqlParameterSource namedParameter=new MapSqlParameterSource(m1);
		return namedParameterJdbcTemplate.query(query, namedParameter,new CircleMapper());
		
	}
	
	
	
	
	

}
