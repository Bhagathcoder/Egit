package com.bhagath;

public interface Shape {
	
	public void draw();

}
